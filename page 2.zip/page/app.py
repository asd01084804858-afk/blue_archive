from flask import Flask, render_template
import json

app = Flask(__name__)

# ==========================================
# 1. 여기서 스토리를 작성하세요 (Python)
# ==========================================
story_script = [
    {
        "id": 1,
        "name": "호시노",
        "affiliation": "대책위원회",
        "text": "으헤~ 선생님, 안녕? 날씨가 참 좋네~ (Python에서 보낸 대사)",
        "bg": "static/images/bg_classroom.jpg",
        "char": "static/images/hoshino_smile.png",
        "bgm": "static/audio/daily_life.mp3"
    },
    {
        "id": 2,
        "name": "호시노",
        "affiliation": "대책위원회",
        "text": "이런 날에는 낮잠이나 자야 하는데 말이야...",
        "bg": "static/images/bg_classroom.jpg",
        "char": "static/images/hoshino_sleepy.png",
        "bgm": "static/audio/daily_life.mp3"
    },
    {
        "id": 3,
        "name": "아로나",
        "affiliation": "싯딤의 상자",
        "text": "선생님! 업무를 땡땡이 치시면 안 돼요!",
        "bg": "static/images/bg_arona.jpg",
        "char": "static/images/arona_angry.png",
        "bgm": "static/audio/comical.mp3"
    }
]

@app.route('/')
def index():
    # Python 데이터를 JSON(자바스크립트가 이해하는 문자열)으로 바꿔서 보냅니다.
    script_json = json.dumps(story_script)
    return render_template('index.html', script_data=script_json)

if __name__ == '__main__':
    app.run(debug=True)